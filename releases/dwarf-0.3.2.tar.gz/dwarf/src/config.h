#ifndef DW_CONFIG_H
#define DW_CONFIG_H

#define VERSION "0.3.2"
#define HAVE_LIBREADLINE 1
#endif